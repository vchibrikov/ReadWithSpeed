//
//  AboutViewController.swift

//
//  Created by Vadym  Chibrikov on 29/01/2022.
//

import UIKit

class AboutViewController: UIViewController {
    
    @IBAction func AcceleReader(_ sender: Any) {
        
        if let url = URL(string: "https://www.accelareader.com/") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
    }
    @IBAction func Konrad(_ sender: Any) {
        
    if let url = URL(string: "https://www.linkedin.com/in/konrad-k%C5%82osok-99a33b1ab/") {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    }
    
    @IBAction func Vadym(_ sender: Any) {
    
        if let url = URL(string: "https://www.linkedin.com/in/chibrikovvadym/") {
          UIApplication.shared.open(url, options: [:], completionHandler: nil)

//    override func viewDidLoad() {
//        super.viewDidLoad()

    }

}
    }
