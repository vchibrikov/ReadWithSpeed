//
//  CalculateViewController.swift

//
//  Created by Vadym  Chibrikov on 09/01/2022.
//

import UIKit
import Foundation

class StartViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var TextLabel: UILabel!
    @IBOutlet weak var SpeedRateStepper: UIStepper!
    @IBOutlet var TextLabelSizeStepper: UIStepper!
    @IBOutlet var TextField: UITextField!
    @IBOutlet var StartReadingButton: UIButton!
    @IBOutlet var StopReadingButton: UIButton!
    
    var timerCounting:Bool = false

    //let TextFieldText : String = TextField.text!
    //let TextFieldTextSplit = TextFieldText.split(separator: " ")
    //TextLabel.text =  "\(TextFieldTextSplit![3])"
        
    //let words = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    
    //let TextFieldText = TextField.text
    
    //let TextFieldText = TextField.text!
    //let TextFieldTextSplit = TextFieldText.split(separator: " ")
    //TextLabel.text =  "\(TextFieldTextSplit![3])"
    
    var counter = 0
    var timer:Timer?
    
    @objc func addWord(){
        
        let TextFieldText = TextField.text!
        let TextFieldTextSplit = TextFieldText.split(separator: " ")
        
        if counter < TextFieldTextSplit.count {
            TextLabel.text = String(Array(TextFieldTextSplit)[counter])
        } else {
                    timer?.invalidate()
                }
        counter = counter + 1
    
}
    
    @IBAction func StartReading(_ sender: UIButton) {
        
        //let TextFieldText = TextField.text!
        //let TextFieldTextSplit = TextFieldText.split(separator: " ")
        
        if(timerCounting)
        {
            timerCounting = false
            timer?.invalidate()
        }
        else
        {
            timerCounting = true
            timer = Timer.scheduledTimer(timeInterval: (1/SpeedRateStepper.value), target: self, selector: #selector(addWord), userInfo: nil, repeats: true)
        }
        
    }
    
    @IBAction func StopReading(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Stop reading?", message: "Are you sure to stop reading?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (_) in
            //do nothing
        }))
        
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { (_) in
            self.counter = 0
            self.timer?.invalidate()
            self.TextLabel.text = " "
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func TextLabelSizeStepperClicked(_ sender: UIStepper) {
        self.TextLabel.font = UIFont.systemFont(ofSize: CGFloat(TextLabelSizeStepper.value))

    }
    
    @IBAction func SpeedRateStepperClicked(_ sender: Any) {
    }
    
    let colorWell: UIColorWell = {
       let colorWell = UIColorWell()
        colorWell.supportsAlpha = true
        colorWell.selectedColor = .systemBackground
        //colorWell.backgroundColor = .tertiarySystemBackground
        colorWell.title = "Color Well"
        return colorWell
    }()
    
    let colorWellText: UIColorWell = {
        let colorWellText = UIColorWell()
        colorWellText.supportsAlpha = true
        colorWellText.selectedColor = .systemBackground
        colorWellText.title = "Color Well Text"
        return colorWellText
    }()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        //view.backgroundColor = .systemBackground
        view.addSubview(colorWell)
        view.addSubview(colorWellText)
        let SpeedRateValue = SpeedRateStepper.value
        //timer = Timer.scheduledTimer(timeInterval: SpeedRateValue, target: self, selector: #selector(addWord), userInfo: nil, repeats: true)
        
        colorWell.addTarget(self, action: #selector(ColorChanged), for: .valueChanged)
        colorWellText.addTarget(self, action: #selector(ColorChangedText), for: .valueChanged)
        //StartReading.layer.cornerRadius = 10
        //StopReading.layer.cornerRadius = 10
        TextLabel.text = " "

        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)

    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        colorWell.frame = CGRect(x: 20,
                                 y: view.safeAreaInsets.top+588,
                                 width: view.frame.size.width-100,
                                 height: 50)
        
        colorWellText.frame = CGRect(x: 20,
                                 y: view.safeAreaInsets.top+630,
                                 width: view.frame.size.width-100,
                                 height: 50)

    }
    
    @objc private func ColorChanged() {
        view.backgroundColor = colorWell.selectedColor
    }
    
    @objc private func ColorChangedText() {
        TextLabel.textColor = colorWellText.selectedColor
    }
    
    @IBAction func TextSizeStepperClicked(_ sender: UIStepper) {
        TextLabel.text = Int(sender.value).description
    }
     
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
}






