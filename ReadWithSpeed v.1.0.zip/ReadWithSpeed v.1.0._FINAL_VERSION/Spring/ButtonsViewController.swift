//
//  ButtonsViewController.swift

//
//  Created by Vadym  Chibrikov on 29/01/2022.
//
import UIKit

class ButtonsViewController: UIViewController {

    @IBOutlet weak var ChooseCantilever: UIButton!
        
    @IBOutlet weak var About: UIButton!
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ChooseCantilever.layer.cornerRadius = 10
        About.layer.cornerRadius = 10

    }

}
